Eric Desrosiers 101265942
"I attest that I am the sole author of this summitted work and any code borrowed from other sources has been 
identified by comments placed in my submitted code.
Eric Desrosiers 101265942"
INSTALL INSTRUCTIONS:
make sure you are in the folder with the package-lock file and then run
npm install
LAUNCH INSTRUCTIONS:
open a terminal and run:
node server.js
TESTING INSTRUCTIONS URL:
http://localhost:3000

sample admin:
user: frank
password: secret2
sample accounts:
username: g
password: g,

username: hunter
password: hunter,

username: lucas,
password: lucas



VIDEO DEMONSTRATION:

https://youtu.be/rADokFDz6pI